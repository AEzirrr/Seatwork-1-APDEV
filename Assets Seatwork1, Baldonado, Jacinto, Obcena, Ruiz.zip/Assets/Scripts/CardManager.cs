using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CardManager : MonoBehaviour
{
    private List<GameObject> cards;

    private void Start()
    {
        //cards = Resources.LoadAll("SAMPLECARDS");


    }
}
