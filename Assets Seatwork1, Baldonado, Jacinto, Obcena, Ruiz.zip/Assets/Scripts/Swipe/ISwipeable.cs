using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ISwipeable
{
    public void OnSwipe(SwipeEventArgs args);

}
